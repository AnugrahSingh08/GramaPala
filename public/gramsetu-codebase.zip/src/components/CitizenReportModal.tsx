import React, { useState, useEffect, useMemo } from 'react';
import { AssetCategory, PriorityLevel, Complaint, Asset } from '../types';
import { 
  X, 
  Upload, 
  Sparkles, 
  Camera, 
  AlertTriangle, 
  CheckCircle2, 
  MapPin, 
  Loader2,
  ShieldAlert,
  Search,
  RefreshCw,
  BarChart2,
  Ticket,
  Send,
  ArrowRight,
  Info
} from 'lucide-react';

interface CitizenReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (complaint: Partial<Complaint>) => void;
  lang: 'en' | 'kn';
  assets?: Asset[];
  complaints?: Complaint[];
}

const SAMPLE_PRESETS = [
  {
    title: 'Broken Streetlight',
    titleKn: 'ಒಡೆದ ಬೀದಿ ದೀಪ',
    category: 'Streetlight' as AssetCategory,
    ward: 'Ward 3',
    location: 'Main Bazaar Road, Near Govt Primary School, Belavadi',
    description: 'Streetlight luminaire has fallen loose and wires are exposed. Dark at night near school.',
    photoUrl: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?auto=format&fit=crop&w=800&q=80',
    gps: { lat: 12.3365, lng: 76.6192 },
  },
  {
    title: 'Burst Water Pipe',
    titleKn: 'ಕುಡಿಯುವ ನೀರಿನ ಪೈಪ್ ಸೋರಿಕೆ',
    category: 'Water Supply' as AssetCategory,
    ward: 'Ward 2',
    location: 'Maramma Temple Street, Ward 2, Belavadi',
    description: 'High pressure drinking water pipe has ruptured, flooding road and wasting village potable water.',
    photoUrl: 'https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=800&q=80',
    gps: { lat: 12.3358, lng: 76.6205 },
  },
  {
    title: 'Dangerous Road Crater',
    titleKn: 'ರಸ್ತೆ ದೊಡ್ಡ ಗುಂಡಿ',
    category: 'Rural Road' as AssetCategory,
    ward: 'Ward 4',
    location: 'Village Entrance Link Road, Ward 4',
    description: 'Deep tarmac subsidence and road hole after rain. 2-wheelers and milk tractors slipping.',
    photoUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80',
    gps: { lat: 12.3382, lng: 76.6174 },
  },
];

export const CitizenReportModal: React.FC<CitizenReportModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  lang,
  assets = [],
  complaints = [],
}) => {
  const [photoUrl, setPhotoUrl] = useState<string>(SAMPLE_PRESETS[0].photoUrl);
  const [category, setCategory] = useState<AssetCategory>('Streetlight');
  const [ward, setWard] = useState<string>('Ward 3');
  const [location, setLocation] = useState<string>(SAMPLE_PRESETS[0].location);
  const [description, setDescription] = useState<string>(SAMPLE_PRESETS[0].description);
  const [citizenName, setCitizenName] = useState<string>('Prakash Rao');
  const [citizenPhone, setCitizenPhone] = useState<string>('+91 98860 12390');
  const [gpsCoordinates, setGpsCoordinates] = useState<{ lat: number; lng: number; accuracy: number }>({
    lat: 12.3365,
    lng: 76.6192,
    accuracy: 2.8,
  });

  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [triageReport, setTriageReport] = useState<any>(null);
  const [matchedAsset, setMatchedAsset] = useState<Asset | null>(null);
  const [duplicateCheck, setDuplicateCheck] = useState<{ isDuplicate: boolean; complaintId?: string; message: string }>({
    isDuplicate: false,
    message: 'Verified unique grievance.',
  });
  const [submittedTicket, setSubmittedTicket] = useState<{ complaintId: string; timestamp: string } | null>(null);

  // Dynamic Community Impact Score calculation (0-100)
  const impactScore = useMemo(() => {
    let score = 60;
    if (category === 'Water Supply' || category === 'Borewell Pump') score += 25;
    if (category === 'Streetlight') score += 18;
    if (category === 'Rural Road') score += 20;
    if (description.toLowerCase().includes('school') || location.toLowerCase().includes('school')) score += 10;
    if (description.toLowerCase().includes('wire') || description.toLowerCase().includes('dark') || description.toLowerCase().includes('danger')) score += 5;
    return Math.min(score, 98);
  }, [category, description, location]);

  // Find Existing Asset from Registry matching GPS/Category
  useEffect(() => {
    const safeAssets = assets || [];
    const candidates = safeAssets.filter((a) => a && (a.category === category || a.ward === ward));
    if (candidates.length > 0) {
      // Find candidate in same ward or closest
      const match = candidates.find((c) => c.ward === ward && c.category === category) || candidates[0];
      setMatchedAsset(match);
    } else {
      setMatchedAsset(safeAssets[0] || null);
    }
  }, [category, ward, assets]);

  // Duplicate Grievance Detection
  useEffect(() => {
    if (!matchedAsset) return;
    const safeComplaints = complaints || [];
    const existing = safeComplaints.find(
      (c) => c && c.assetId === matchedAsset.id && (c.status === 'Pending' || c.status === 'Assigned' || c.status === 'In Progress')
    );
    if (existing) {
      setDuplicateCheck({
        isDuplicate: true,
        complaintId: existing.id,
        message: `Existing open grievance (${existing.id}) found on this asset. Submitting will co-sign and escalate urgency to Priority 1!`,
      });
    } else {
      setDuplicateCheck({
        isDuplicate: false,
        message: 'No open grievances within 150m. Clean new submission.',
      });
    }
  }, [matchedAsset, complaints]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoUrl(reader.result as string);
        runDiagnostics(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const applyPreset = (preset: typeof SAMPLE_PRESETS[0]) => {
    setCategory(preset.category);
    setWard(preset.ward);
    setLocation(preset.location);
    setDescription(preset.description);
    setPhotoUrl(preset.photoUrl);
    setGpsCoordinates({ lat: preset.gps.lat, lng: preset.gps.lng, accuracy: 2.5 });
    setTriageReport(null);
  };

  const runDiagnostics = async (imgUrl = photoUrl) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/grievance/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imgUrl,
          userNotes: description,
          assetHint: category,
          ward: ward,
        }),
      });
      const data = await response.json();
      if (data?.analysis) {
        setTriageReport(data.analysis);
        if (data.analysis.assetType) {
          const matchedCat = ['Streetlight', 'Water Supply', 'Public Toilet', 'Rural Road', 'Borewell Pump', 'Drainage'].find(
            (c) => c.toLowerCase() === data.analysis.assetType.toLowerCase()
          );
          if (matchedCat) setCategory(matchedCat as AssetCategory);
        }
      }
    } catch (err) {
      console.error('Classification error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedId = `GR-2026-MYS-${Math.floor(100 + Math.random() * 900)}`;
    const newComplaintData: Partial<Complaint> = {
      id: generatedId,
      assetId: matchedAsset?.id || (category === 'Streetlight' ? 'KA-MYS-SL-102' : 'KA-MYS-WP-018'),
      assetName: matchedAsset?.name || `${category} Asset (${ward})`,
      category,
      location,
      ward,
      reportedBy: {
        name: citizenName,
        phone: citizenPhone,
        village: 'Belavadi Gram Panchayat',
      },
      description,
      descriptionKn: triageReport?.formalSummaryKn || 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ದುರಸ್ತಿ ಕೋರಿಕೆ',
      photoUrl,
      status: 'Pending',
      priority: (triageReport?.damageSeverity as PriorityLevel) || 'High',
      slaDeadline: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      gpsCoordinates: {
        lat: gpsCoordinates.lat,
        lng: gpsCoordinates.lng,
        accuracyMeters: gpsCoordinates.accuracy,
      },
      matchedAssetDistanceMeters: 28,
      duplicateStatus: {
        isDuplicate: duplicateCheck.isDuplicate,
        existingComplaintId: duplicateCheck.complaintId,
        message: duplicateCheck.message,
      },
      communityImpactScore: impactScore,
      communityImpactDetails: {
        householdsAffected: Math.floor(impactScore * 4.2),
        vitalService: category === 'Water Supply' ? 'Drinking Water Line' : 'Rural Electrification & Safety',
        riskFactor: triageReport?.hazardWarning || 'Public safety and mobility hazard',
      },
      triage: triageReport || {
        assetType: category,
        damageSeverity: 'High',
        recommendedSLA: '24 Hours',
        specialistRequired: category === 'Streetlight' ? 'Electrician' : 'Plumbing Technician',
        kannadaTitle: 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ದುರಸ್ತಿ',
        formalSummaryEn: description,
        formalSummaryKn: 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ದುರಸ್ತಿ ಅಗತ್ಯವಿದೆ.',
        hazardWarning: 'Precaution advised in the vicinity.',
        suggestedAction: 'Dispatch field inspection squad.',
      },
      aiTriage: triageReport || {
        assetType: category,
        damageSeverity: 'High',
        recommendedSLA: '24 Hours',
        specialistRequired: category === 'Streetlight' ? 'Electrician' : 'Plumbing Technician',
        kannadaTitle: 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ದುರಸ್ತಿ',
        formalSummaryEn: description,
        formalSummaryKn: 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ದುರಸ್ತಿ ಅಗತ್ಯವಿದೆ.',
        hazardWarning: 'Precaution advised in the vicinity.',
        suggestedAction: 'Dispatch field inspection squad.',
      },
    };

    onSubmit(newComplaintData);
    setSubmittedTicket({
      complaintId: generatedId,
      timestamp: new Date().toLocaleTimeString(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Plus_Jakarta_Sans',sans-serif]">
      <div className="relative bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Ticket Confirmation Screen if just submitted */}
        {submittedTicket ? (
          <div className="p-6 text-center space-y-5 animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner border border-emerald-300">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-black uppercase tracking-wider">
                <Ticket className="w-3.5 h-3.5" />
                <span>GovTech Grievance Dispatched</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900">
                Ticket Generated: {submittedTicket.complaintId}
              </h2>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Your grievance has been auto-triaged, matched to registered public asset{' '}
                <span className="font-bold text-slate-800">{matchedAsset?.id}</span>, and routed to the Belavadi Panchayat Development Officer.
              </p>
            </div>

            {/* Receipt Card */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 max-w-md mx-auto text-left text-xs space-y-2.5">
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-semibold">Community Impact Score</span>
                <span className="font-black text-indigo-700">{impactScore} / 100 (High)</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-semibold">Matched Asset</span>
                <span className="font-bold text-slate-800">{matchedAsset?.name} ({matchedAsset?.id})</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-semibold">GPS Coordinates</span>
                <span className="font-mono text-slate-700">{gpsCoordinates.lat}° N, {gpsCoordinates.lng}° E</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">Target SLA</span>
                <span className="font-bold text-red-700">24 Hours (Immediate Worker Dispatch)</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-center space-x-3">
              <button
                type="button"
                onClick={() => {
                  setSubmittedTicket(null);
                  onClose();
                }}
                className="bg-slate-900 hover:bg-slate-800 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
              >
                Track in Citizen Dashboard
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center font-bold shadow-md shadow-amber-500/20">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900">
                    {lang === 'kn' ? 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ಹಾನಿ ದೂರು (Citizen Grievance)' : 'Citizen Grievance: Capture Damaged Asset'}
                  </h2>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Automated diagnostics, GPS geo-tagging, duplicate screening, and impact scoring.
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Demo Presets Strip */}
            <div className="pt-2.5 pb-2">
              <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5 font-bold">
                <span>⚡ Quick Test Presets:</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {SAMPLE_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => applyPreset(preset)}
                    className="text-left text-xs p-2 rounded-xl border border-slate-200 hover:border-amber-500 hover:bg-amber-50/50 transition-all cursor-pointer group"
                  >
                    <div className="font-bold text-slate-800 group-hover:text-amber-800 line-clamp-1">
                      {preset.title}
                    </div>
                    <div className="text-[10px] text-slate-500">{preset.ward}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Scrollable Form Body */}
            <form onSubmit={handleSubmit} className="overflow-y-auto space-y-3.5 pt-1 pr-1 flex-1">
              {/* Step 1: 📷 Photo Capture & Diagnostics */}
              <div className="bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-600" />
                    <span>Step 1: 📷 Photo Capture & Diagnostics</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => runDiagnostics()}
                    disabled={isAnalyzing}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isAnalyzing ? 'Analyzing...' : 'Re-scan Photo'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                  <div className="sm:col-span-5 relative h-32 rounded-xl overflow-hidden border-2 border-dashed border-amber-400 bg-amber-50 flex items-center justify-center group">
                    <img
                      src={photoUrl}
                      alt="Asset damage"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer text-white text-xs font-bold gap-1">
                      <Upload className="w-4 h-4" />
                      <span>Upload New Photo</span>
                      <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                    </label>
                  </div>

                  <div className="sm:col-span-7 space-y-1.5 text-xs">
                    {isAnalyzing ? (
                      <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center space-x-2 text-indigo-800 font-bold">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Analyzing image parameters, asset classification & damage severity...</span>
                      </div>
                    ) : triageReport ? (
                      <div className="p-2.5 bg-white border border-indigo-200 rounded-xl space-y-1 shadow-xs">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-extrabold text-indigo-900">Detected: {triageReport.assetType}</span>
                          <span className="font-black text-red-700 bg-red-100 px-1.5 py-0.5 rounded">Severity: {triageReport.damageSeverity}</span>
                        </div>
                        <p className="text-[11px] text-slate-700 leading-snug line-clamp-2">{triageReport.formalSummaryEn}</p>
                        {triageReport.hazardWarning && (
                          <div className="text-[10px] text-amber-900 bg-amber-50 px-2 py-0.5 rounded font-medium">
                            ⚠️ {triageReport.hazardWarning}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px] space-y-1">
                        <div className="font-bold">Detected Asset: {category}</div>
                        <div>Fault: Damaged fixture & loose exposed conductor.</div>
                        <button
                          type="button"
                          onClick={() => runDiagnostics()}
                          className="text-[10px] font-black underline text-amber-800 cursor-pointer"
                        >
                          Run Full Diagnostics
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Step 2: 📍 GPS Geotagging & 🔎 Find Existing Asset */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* 📍 GPS Status */}
                <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-blue-900 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-blue-600" />
                      <span>Step 2: 📍 GPS Geotag</span>
                    </span>
                    <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded">
                      GPS Locked (±{gpsCoordinates.accuracy}m)
                    </span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-700">
                    {gpsCoordinates.lat}° N, {gpsCoordinates.lng}° E
                  </div>
                  <div className="text-[10px] text-slate-500">{location}</div>
                </div>

                {/* 🔎 Find Existing Asset */}
                <div className="p-3 rounded-xl bg-indigo-50/70 border border-indigo-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-indigo-900 flex items-center gap-1">
                      <Search className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Step 3: 🔎 Registry Match</span>
                    </span>
                    <span className="text-[10px] font-bold text-indigo-700">28m away</span>
                  </div>
                  <div className="font-bold text-slate-900">
                    {matchedAsset?.name || 'Streetlight SL-102 (LED Smart Mast)'}
                  </div>
                  <div className="text-[10px] text-slate-600">
                    Passport ID: <span className="font-mono font-bold text-indigo-800">{matchedAsset?.id || 'KA-MYS-SL-102'}</span>
                  </div>
                </div>
              </div>

              {/* Step 3: 🔄 Duplicate Detection & 📊 Community Impact Score */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* 🔄 Duplicate Detection */}
                <div className={`p-3 rounded-xl border text-xs space-y-1 ${
                  duplicateCheck.isDuplicate
                    ? 'bg-amber-50 border-amber-300 text-amber-950'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold flex items-center gap-1">
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Step 4: 🔄 Duplicate Check</span>
                    </span>
                    <span className={`text-[10px] font-black px-1.5 py-0.2 rounded ${
                      duplicateCheck.isDuplicate ? 'bg-amber-200 text-amber-900' : 'bg-emerald-200 text-emerald-900'
                    }`}>
                      {duplicateCheck.isDuplicate ? 'Duplicate Found' : 'Verified Unique'}
                    </span>
                  </div>
                  <p className="text-[11px] leading-tight">
                    {duplicateCheck.message}
                  </p>
                </div>

                {/* 📊 Community Impact Score */}
                <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-purple-950 flex items-center gap-1">
                      <BarChart2 className="w-3.5 h-3.5 text-purple-600" />
                      <span>Step 5: 📊 Impact Score</span>
                    </span>
                    <span className="text-[11px] font-black bg-purple-200 text-purple-900 px-2 py-0.5 rounded-full">
                      {impactScore} / 100
                    </span>
                  </div>
                  <div className="w-full bg-purple-200/60 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-purple-600 h-full rounded-full" style={{ width: `${impactScore}%` }} />
                  </div>
                  <div className="text-[10px] text-purple-800 font-medium">
                    High Priority • Affects ~{Math.floor(impactScore * 4.2)} villagers • Critical route
                  </div>
                </div>
              </div>

              {/* Asset Category & Ward Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Asset Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as AssetCategory)}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="Streetlight">Streetlight (ಬೀದಿ ದೀಪ)</option>
                    <option value="Water Supply">Water Pipeline / Taps (ಕುಡಿಯುವ ನೀರು)</option>
                    <option value="Borewell Pump">Borewell Pump (ಕೊಳವೆಬಾವಿ ಪಂಪ್)</option>
                    <option value="Rural Road">Rural Road / Pothole (ಗ್ರಾಮೀಣ ರಸ್ತೆ)</option>
                    <option value="Public Toilet">Public Toilet (ಸಾರ್ವಜನಿಕ ಶೌಚಾಲಯ)</option>
                    <option value="Drainage">Drainage Canal (ಚರಂಡಿ)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Panchayat Ward
                  </label>
                  <select
                    value={ward}
                    onChange={(e) => setWard(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="Ward 1">Ward 1 - North Belavadi</option>
                    <option value="Ward 2">Ward 2 - Temple Street</option>
                    <option value="Ward 3">Ward 3 - Milk Dairy & High School</option>
                    <option value="Ward 4">Ward 4 - Chamundi Approach Link</option>
                  </select>
                </div>
              </div>

              {/* Citizen Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-0.5">
                    Citizen Name
                  </label>
                  <input
                    type="text"
                    value={citizenName}
                    onChange={(e) => setCitizenName(e.target.value)}
                    required
                    className="w-full text-xs font-medium px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-0.5">
                    Mobile Phone (SMS & Verification updates)
                  </label>
                  <input
                    type="text"
                    value={citizenPhone}
                    onChange={(e) => setCitizenPhone(e.target.value)}
                    required
                    className="w-full text-xs font-medium px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                </div>
              </div>

              {/* Submit Action: 📤 Submit → 🎫 Complaint ID */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                <div className="text-[11px] text-slate-500 font-medium">
                  Generates official Complaint ID with instant tracking receipt.
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center space-x-1.5 bg-gradient-to-r from-amber-600 to-indigo-600 hover:from-amber-700 hover:to-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-md shadow-amber-600/20 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>📤 Submit & Generate Complaint ID</span>
                  </button>
                </div>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
