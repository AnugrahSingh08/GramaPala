import React from 'react';
import { ActiveRole, LanguageMode } from '../types';
import { ThemeConfig } from '../types/theme';
import { 
  Building2, 
  User, 
  Wrench, 
  FileText, 
  BarChart3, 
  Languages, 
  Camera
} from 'lucide-react';

interface NavbarProps {
  activeRole: ActiveRole;
  onRoleChange: (role: ActiveRole) => void;
  lang: LanguageMode;
  onToggleLang: () => void;
  pendingVerificationsCount: number;
  unassignedComplaintsCount: number;
  assignedTasksCount: number;
  onOpenDemoFlow?: () => void;
  onOpenReportModal: () => void;
  onOpenDevHub?: () => void;
  theme: ThemeConfig;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeRole,
  onRoleChange,
  lang,
  onToggleLang,
  pendingVerificationsCount,
  unassignedComplaintsCount,
  assignedTasksCount,
  onOpenReportModal,
  theme,
}) => {
  return (
    <header className={`sticky top-0 z-40 ${theme.classes.navBg} border-b ${theme.classes.navBorder} shadow-xs transition-colors duration-300`}>
      {/* Top Karnataka GovTech Banner */}
      <div className={`${theme.classes.topBannerBg} border-b ${theme.classes.topBannerBorder} ${theme.classes.topBannerText} text-xs px-4 py-2 flex items-center justify-between font-medium transition-colors duration-300`}>
        <div className="flex items-center space-x-2">
          <span className="inline-block w-2 h-2 rounded-full bg-amber-400"></span>
          <span className="font-semibold tracking-wide">
            {lang === 'kn'
              ? 'ಕರ್ನಾಟಕ ಸರ್ಕಾರ • ಗ್ರಾಮೀಣಾಭಿವೃದ್ಧಿ ಮತ್ತು ಪಂಚಾಯತ್ ರಾಜ್ ಇಲಾಖೆ'
              : 'Government of Karnataka • Dept. of Rural Development & Panchayat Raj'}
          </span>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="flex items-center space-x-1.5 hover:opacity-90 transition-colors bg-white/10 hover:bg-white/15 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer border border-white/20"
            title="Switch Language"
          >
            <Languages className="w-3.5 h-3.5 text-amber-300" />
            <span>{lang === 'kn' ? 'English' : 'ಕನ್ನಡ'}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-2.5 shrink-0">
            <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl ${theme.classes.logoBg} flex items-center justify-center font-black text-white shadow-sm transition-all duration-300`}>
              <Building2 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className={`text-base sm:text-lg font-black tracking-tight ${theme.classes.textPrimary}`}>
                  {lang === 'kn' ? 'ಗ್ರಾಮ ಸೇತು' : 'GramSetu'}
                </span>
              </div>
              <p className={`text-[10px] ${theme.classes.textSecondary} font-medium hidden xl:block leading-tight`}>
                {lang === 'kn'
                  ? 'ಸಾರ್ವಜನಿಕ ಆಸ್ತಿ ನಿರ್ವಹಣೆ'
                  : 'Public Asset Grievance & Verification'}
              </p>
            </div>
          </div>

          {/* Desktop/Tablet Role Switcher Tabs (Compact, Zero Slider) */}
          <nav 
            className={`hidden md:flex items-center gap-1 ${
              theme.isDark ? 'bg-slate-800/90 border-slate-700' : 'bg-slate-100/90 border-slate-200/90'
            } p-1 rounded-xl border shadow-2xs shrink-0`}
            aria-label="Dashboard Role Navigation"
          >
            {/* Citizen */}
            <button
              id="nav-role-citizen"
              onClick={() => onRoleChange('citizen')}
              className={`flex items-center gap-1.5 px-2.5 py-1.2 rounded-lg text-[11px] lg:text-xs font-bold transition-all relative cursor-pointer ${
                activeRole === 'citizen'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <User className="w-3.5 h-3.5 shrink-0" style={{ color: theme.swatchPrimary }} />
              <span className="whitespace-nowrap">{lang === 'kn' ? 'ನಾಗರಿಕ' : 'Citizen'}</span>
              {pendingVerificationsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" title="Pending Verification" />
              )}
            </button>

            {/* Panchayat Officer */}
            <button
              id="nav-role-panchayat"
              onClick={() => onRoleChange('panchayat')}
              className={`flex items-center gap-1.5 px-2.5 py-1.2 rounded-lg text-[11px] lg:text-xs font-bold transition-all relative cursor-pointer ${
                activeRole === 'panchayat'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <Building2 className="w-3.5 h-3.5 shrink-0" style={{ color: theme.swatchPrimary }} />
              <span className="whitespace-nowrap">{lang === 'kn' ? 'ಪಂಚಾಯತ್' : 'Panchayat'}</span>
              {unassignedComplaintsCount > 0 && (
                <span className="bg-red-500 text-white text-[9px] px-1.5 py-0.2 rounded-full font-extrabold leading-none">
                  {unassignedComplaintsCount}
                </span>
              )}
            </button>

            {/* Worker */}
            <button
              id="nav-role-worker"
              onClick={() => onRoleChange('worker')}
              className={`flex items-center gap-1.5 px-2.5 py-1.2 rounded-lg text-[11px] lg:text-xs font-bold transition-all relative cursor-pointer ${
                activeRole === 'worker'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <Wrench className="w-3.5 h-3.5 shrink-0" style={{ color: theme.swatchPrimary }} />
              <span className="whitespace-nowrap">{lang === 'kn' ? 'ಕ್ಷೇತ್ರ ಕರ್ಮಿಕ' : 'Field Worker'}</span>
              {assignedTasksCount > 0 && (
                <span className="bg-emerald-600 text-white text-[9px] px-1.5 py-0.2 rounded-full font-extrabold leading-none">
                  {assignedTasksCount}
                </span>
              )}
            </button>

            {/* Asset Passport */}
            <button
              id="nav-role-passport"
              onClick={() => onRoleChange('asset_passport')}
              className={`flex items-center gap-1.5 px-2.5 py-1.2 rounded-lg text-[11px] lg:text-xs font-bold transition-all relative cursor-pointer ${
                activeRole === 'asset_passport'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <FileText className="w-3.5 h-3.5 shrink-0 text-slate-500" />
              <span className="whitespace-nowrap">{lang === 'kn' ? 'ಆಸ್ತಿ ಪಾಸ್‌ಪೋರ್ಟ್' : 'Asset Passport'}</span>
            </button>

            {/* GovTech Analytics */}
            <button
              id="nav-role-analytics"
              onClick={() => onRoleChange('analytics')}
              className={`flex items-center gap-1.5 px-2.5 py-1.2 rounded-lg text-[11px] lg:text-xs font-bold transition-all relative cursor-pointer ${
                activeRole === 'analytics'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 shrink-0 text-slate-500" />
              <span className="whitespace-nowrap">{lang === 'kn' ? 'ವಿಶ್ಲೇಷಣೆ & GIS' : 'Analytics & GIS'}</span>
            </button>
          </nav>

          {/* Quick Action Button for Citizen */}
          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={onOpenReportModal}
              className={`flex items-center space-x-1.5 ${theme.classes.btnPrimary} ${theme.classes.btnPrimaryHover} ${theme.classes.btnPrimaryText} px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold shadow-xs ${theme.classes.btnPrimaryShadow} transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer`}
              title="Report Broken Asset"
            >
              <Camera className="w-3.5 h-3.5 opacity-90" />
              <span className="hidden sm:inline">{lang === 'kn' ? '+ ಹೊಸ ದೂರು' : '+ Report Asset'}</span>
              <span className="sm:hidden font-bold">{lang === 'kn' ? '+ ದೂರು' : '+ Report'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Dedicated Segmented Bar (100% visible, no slider, zero congestion) */}
        <div className="md:hidden pb-2 pt-0.5">
          <nav 
            className={`grid grid-cols-5 gap-1 ${
              theme.isDark ? 'bg-slate-800/95 border-slate-700' : 'bg-slate-100/95 border-slate-200'
            } p-1 rounded-xl border shadow-2xs`}
            aria-label="Mobile Role Navigation"
          >
            <button
              onClick={() => onRoleChange('citizen')}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer relative ${
                activeRole === 'citizen'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <User className="w-3.5 h-3.5" style={{ color: theme.swatchPrimary }} />
              <span className="truncate w-full text-center mt-0.5">
                {lang === 'kn' ? 'ನಾಗರಿಕ' : 'Citizen'}
              </span>
              {pendingVerificationsCount > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 absolute top-1 right-1" />
              )}
            </button>

            <button
              onClick={() => onRoleChange('panchayat')}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer relative ${
                activeRole === 'panchayat'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <Building2 className="w-3.5 h-3.5" style={{ color: theme.swatchPrimary }} />
              <span className="truncate w-full text-center mt-0.5">
                {lang === 'kn' ? 'ಪಂಚಾಯತ್' : 'Panchayat'}
              </span>
              {unassignedComplaintsCount > 0 && (
                <span className="bg-red-500 text-white text-[8px] px-1 py-0.1 rounded-full font-bold absolute top-0.5 right-0.5">
                  {unassignedComplaintsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onRoleChange('worker')}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer relative ${
                activeRole === 'worker'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <Wrench className="w-3.5 h-3.5" style={{ color: theme.swatchPrimary }} />
              <span className="truncate w-full text-center mt-0.5">
                {lang === 'kn' ? 'ಕರ್ಮಿಕ' : 'Worker'}
              </span>
              {assignedTasksCount > 0 && (
                <span className="bg-emerald-600 text-white text-[8px] px-1 py-0.1 rounded-full font-bold absolute top-0.5 right-0.5">
                  {assignedTasksCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onRoleChange('asset_passport')}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer relative ${
                activeRole === 'asset_passport'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span className="truncate w-full text-center mt-0.5">
                {lang === 'kn' ? 'ಪಾಸ್‌ಪೋರ್ಟ್' : 'Passport'}
              </span>
            </button>

            <button
              onClick={() => onRoleChange('analytics')}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer relative ${
                activeRole === 'analytics'
                  ? theme.classes.activeNavTab
                  : theme.classes.inactiveNavTab
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-slate-500" />
              <span className="truncate w-full text-center mt-0.5">
                {lang === 'kn' ? 'ವಿಶ್ಲೇಷಣೆ' : 'Analytics'}
              </span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
