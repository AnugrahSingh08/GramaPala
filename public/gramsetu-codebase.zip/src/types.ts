export type AssetCategory =
  | 'Streetlight'
  | 'Water Supply'
  | 'Public Toilet'
  | 'Rural Road'
  | 'Borewell Pump'
  | 'Drainage';

export type AssetStatus = 'Working' | 'Degraded' | 'Critical Failure' | 'Under Repair';

export type ComplaintStatus =
  | 'Pending'
  | 'Assigned'
  | 'In Progress'
  | 'Completed'
  | 'Closed'
  | 'Reopened';

export type PriorityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export interface RepairProof {
  photoUrl: string;
  beforePhotoUrl?: string;
  completedAt: string;
  workerNotes: string;
  partsReplaced?: string[];
  geoTag: string;
  contractorVerified: boolean;
  actionType?: 'Repair' | 'Replace';
  repairCost?: {
    partsCost: number;
    laborCost: number;
    totalCost: number;
  };
  qaVerification?: {
    verified: boolean;
    confidence: number;
    summary: string;
    inspectedAt: string;
  };
  aiRepairVerification?: {
    verified: boolean;
    confidence: number;
    summary: string;
    inspectedAt: string;
  };
}

export interface RepairGalleryPhoto {
  id?: string;
  url: string;
  caption: string;
  type: 'damage_report' | 'repair_proof' | 'component' | 'inspection';
  timestamp?: string;
  geoTag?: string;
  capturedBy?: string;
}

export interface AssetRepairRecord {
  complaintId: string;
  date: string;
  issue: string;
  resolvedInDays: number;
  workerName: string;
  status: 'Closed' | 'Reopened' | 'Pending';
  costInr: number;
  partsReplaced?: string;
  repairProof?: RepairProof;
  damagePhotoUrl?: string;
  galleryPhotos?: RepairGalleryPhoto[];
}

export interface Asset {
  id: string; // e.g. "KA-MYS-SL-102"
  name: string;
  category: AssetCategory;
  panchayat: string; // e.g. "Mysuru Rural Taluk"
  ward: string; // "Ward 3"
  location?: string; // Human-readable location, e.g. "Main Bazaar Junction, Belavadi"
  coordinates: { lat: number; lng: number };
  status: AssetStatus;
  installationDate: string;
  contractor: string;
  warrantyExpiry: string;
  isUnderWarranty: boolean;
  isLemonAsset: boolean; // 3+ breakdowns or recurring quality defect
  failureCount: number;
  imageUrl: string;
  repairHistory: AssetRepairRecord[];
  qrCodeUrl?: string;
  futureFailurePrediction?: {
    riskScore: number;
    predictedFailureDate: string;
    mtbfDays: number;
    riskReason: string;
    preventiveAction: string;
  };
  repairVsReplaceRecommendation?: {
    recommendation: 'Repair' | 'Replace';
    cumulativeRepairCostInr: number;
    newUnitCostInr: number;
    savingsEstimateInr: number;
    justification: string;
  };
}

export interface WorkerInfo {
  id: string;
  name: string;
  phone: string;
  trade: string;
  panchayat: string;
  activeTasks: number;
  completedTasks: number;
  rating: number;
}

export interface CitizenVerification {
  verifiedAt: string;
  decision: 'Fixed' | 'Not Fixed';
  feedback?: string;
  rating?: number;
}

export interface TriageReport {
  assetType: string;
  damageSeverity: 'Critical' | 'High' | 'Medium' | 'Low';
  recommendedSLA: string;
  specialistRequired: string;
  kannadaTitle: string;
  formalSummaryEn: string;
  formalSummaryKn: string;
  hazardWarning: string;
  suggestedAction: string;
  lemonAssetCheck?: string;
}

export interface WorkOrder {
  orderId: string;
  issuedAt: string;
  authorizedBudget: number;
  actionType: 'Repair' | 'Replace';
  targetSla: string;
  pdoApprovalSignature: string;
  instructions: string;
}

export interface Complaint {
  id: string; // e.g. "CMP-2026-101"
  assetId: string;
  assetName: string;
  category: AssetCategory;
  location: string;
  ward: string;
  reportedBy: {
    name: string;
    phone: string;
    village: string;
  };
  reportedAt: string;
  description: string;
  descriptionKn?: string;
  photoUrl: string;
  status: ComplaintStatus;
  priority: PriorityLevel;
  slaDeadline: string;
  assignedWorker?: WorkerInfo;
  assignedAt?: string;
  repairProof?: RepairProof;
  citizenVerification?: CitizenVerification;
  triage?: TriageReport;
  aiTriage?: TriageReport;
  reopenCount?: number;
  gpsCoordinates?: { lat: number; lng: number; accuracyMeters: number };
  matchedAssetDistanceMeters?: number;
  duplicateStatus?: {
    isDuplicate: boolean;
    existingComplaintId?: string;
    reportedHoursAgo?: number;
    coSignersCount?: number;
    message: string;
  };
  communityImpactScore?: number; // 0-100 impact score
  communityImpactDetails?: {
    householdsAffected: number;
    vitalService: string;
    riskFactor: string;
  };
  workOrder?: WorkOrder;
}

export type ActiveRole = 'citizen' | 'panchayat' | 'worker' | 'asset_passport' | 'analytics';

export type LanguageMode = 'en' | 'kn';

export interface PdoNotificationAlert {
  id: string;
  complaintId: string;
  title: string;
  titleKn?: string;
  category: AssetCategory;
  ward: string;
  location: string;
  priority: PriorityLevel;
  reportedAt: string;
  slaDeadline: string;
  reportedBy: {
    name: string;
    phone: string;
    village?: string;
  };
  assetId: string;
  assetName: string;
  hazardWarning?: string;
  aiSummary?: string;
  timestamp: number;
  acknowledged?: boolean;
}
