import React, { useState, useEffect } from 'react';
import { ActiveRole, LanguageMode, Asset, Complaint, WorkerInfo, PdoNotificationAlert, WorkOrder } from './types';
import { THEMES } from './types/theme';
import { INITIAL_ASSETS, INITIAL_COMPLAINTS, INITIAL_WORKERS } from './data/mockData';
import { Navbar } from './components/Navbar';
import { CitizenHome } from './components/CitizenHome';
import { CitizenReportModal } from './components/CitizenReportModal';
import { CitizenVerifyModal } from './components/CitizenVerifyModal';
import { PanchayatDashboard } from './components/PanchayatDashboard';
import { WorkerDashboard } from './components/WorkerDashboard';
import { AssetPassportView } from './components/AssetPassportView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { GuidedDemoModal } from './components/GuidedDemoModal';
import { PdoNotificationBanner } from './components/PdoNotificationBanner';
import { HackathonDevHubModal } from './components/HackathonDevHubModal';
import { Footer } from './components/Footer';
import { notifyPdoCriticalGrievance, isCriticalGrievance } from './utils/notificationSystem';
import { 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';

export default function App() {
  const [activeRole, setActiveRole] = useState<ActiveRole>('citizen');
  const [lang, setLang] = useState<LanguageMode>('en');

  // App State with local storage fallback
  const [assets, setAssets] = useState<Asset[]>(() => {
    try {
      const saved = localStorage.getItem('gramsetu_assets');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Asset storage parse error', e);
    }
    return INITIAL_ASSETS;
  });

  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    try {
      const saved = localStorage.getItem('gramsetu_complaints');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Complaint storage parse error', e);
    }
    return INITIAL_COMPLAINTS;
  });

  const [workers, setWorkers] = useState<WorkerInfo[]>(INITIAL_WORKERS);
  const [currentWorkerId, setCurrentWorkerId] = useState<string>(INITIAL_WORKERS[0]?.id || 'W-01');
  const [selectedAssetId, setSelectedAssetId] = useState<string>(INITIAL_ASSETS[0]?.id || 'AST-KA-MYS-001');

  // Modals state
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [verifyComplaintTarget, setVerifyComplaintTarget] = useState<Complaint | null>(null);
  const [isDemoFlowOpen, setIsDemoFlowOpen] = useState<boolean>(false);
  const [isDevHubOpen, setIsDevHubOpen] = useState<boolean>(false);
  const [targetComplaintId, setTargetComplaintId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; type: 'success' | 'alert' } | null>(null);

  // Finalized Karnataka Royal Navy & Gold Theme
  const currentTheme = THEMES.royal;

  // Persistent automated PDO notification alerts
  const [pdoAlerts, setPdoAlerts] = useState<PdoNotificationAlert[]>(() => {
    try {
      const saved = localStorage.getItem('gramsetu_pdo_alerts');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Alert storage sync error', e);
    }
    // Initialize with pending critical street light issue if available
    const initialCritical = INITIAL_COMPLAINTS.find(
      (c) => c.id === 'CMP-2026-101' && c.status === 'Pending'
    );
    if (initialCritical) {
      return [notifyPdoCriticalGrievance(initialCritical)];
    }
    return [];
  });

  // Auto-sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('gramsetu_assets', JSON.stringify(assets));
    } catch (e) {
      console.warn('Storage sync failed', e);
    }
  }, [assets]);

  useEffect(() => {
    try {
      localStorage.setItem('gramsetu_complaints', JSON.stringify(complaints));
    } catch (e) {
      console.warn('Storage sync failed', e);
    }
  }, [complaints]);

  useEffect(() => {
    try {
      localStorage.setItem('gramsetu_pdo_alerts', JSON.stringify(pdoAlerts));
    } catch (e) {
      console.warn('Storage sync failed', e);
    }
  }, [pdoAlerts]);

  // Subtle developer shortcut (Ctrl+Shift+E) to open code exporter if needed
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'e') {
        setIsDevHubOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const showToast = (title: string, desc: string, type: 'success' | 'alert' = 'success') => {
    setToastMessage({ title, desc, type });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // 1. Citizen reports complaint
  const handleCreateComplaint = (newComplaintData: Partial<Complaint>) => {
    const newId = `CMP-2026-${Math.floor(100 + Math.random() * 900)}`;
    const fullComplaint: Complaint = {
      id: newId,
      assetId: newComplaintData.assetId || 'KA-MYS-SL-102',
      assetName: newComplaintData.assetName || 'Public Asset',
      category: newComplaintData.category || 'Streetlight',
      location: newComplaintData.location || 'Ward 3 Junction',
      ward: newComplaintData.ward || 'Ward 3',
      reportedBy: newComplaintData.reportedBy || {
        name: 'Citizen',
        phone: '+91 98860 12390',
        village: 'Belavadi GP',
      },
      reportedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      description: newComplaintData.description || '',
      descriptionKn: newComplaintData.descriptionKn,
      photoUrl: newComplaintData.photoUrl || '',
      status: 'Pending',
      priority: newComplaintData.priority || 'High',
      slaDeadline: newComplaintData.slaDeadline || new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      aiTriage: newComplaintData.aiTriage,
    };

    setComplaints((prev) => [fullComplaint, ...prev]);

    // Update corresponding asset failure count & repair history
    setAssets((prev) =>
      prev.map((asset) => {
        if (asset.id === fullComplaint.assetId) {
          const newFailCount = asset.failureCount + 1;
          return {
            ...asset,
            status: 'Critical Failure',
            failureCount: newFailCount,
            isLemonAsset: newFailCount >= 3, // Flag as lemon asset if >=3 breakdowns
            repairHistory: [
              ...asset.repairHistory,
              {
                complaintId: newId,
                date: fullComplaint.reportedAt.split(' ')[0],
                issue: fullComplaint.description,
                resolvedInDays: 0,
                workerName: 'Pending Assignment',
                status: 'Pending',
                costInr: 0,
              },
            ],
          };
        }
        return asset;
      })
    );

    // Automated Notification System for Panchayat PDOs
    if (isCriticalGrievance(fullComplaint)) {
      const alertData = notifyPdoCriticalGrievance(fullComplaint);
      setPdoAlerts((prev) => [alertData, ...prev.filter((a) => a.complaintId !== alertData.complaintId)]);
      showToast(
        'Critical Grievance Dispatched to PDO!',
        `Automated SOS broadcast triggered for ${fullComplaint.category} in ${fullComplaint.ward}.`,
        'alert'
      );
    } else {
      showToast(
        'Grievance Registered Successfully!',
        `Complaint ${newId} logged. Assigned to Panchayat queue.`
      );
    }
  };

  // 2. Panchayat assigns field worker
  const handleAssignWorker = (complaintId: string, workerId: string, workOrder?: WorkOrder) => {
    const worker = workers.find((w) => w.id === workerId);
    if (!worker) return;

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: 'Assigned',
            assignedWorker: worker,
            assignedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            workOrder: workOrder || {
              orderId: `WO-2026-MYS-${Math.floor(100 + Math.random() * 900)}`,
              issuedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
              authorizedBudget: 2200,
              actionType: 'Repair',
              targetSla: '24 Hours',
              pdoApprovalSignature: 'M. S. Patil (Belavadi PDO)',
              instructions: 'Inspect and repair asset according to technical specifications.',
            },
          };
        }
        return c;
      })
    );

    // Clear alert from active PDO emergency banner when technician is assigned
    setPdoAlerts((prev) => prev.filter((a) => a.complaintId !== complaintId));
    console.log(
      `%c[KRDPR PDO WORK ORDER DISPATCHED]%c Complaint ${complaintId} successfully assigned to ${worker.name} (${worker.trade}). Emergency alert resolved.`,
      'background: #059669; color: #fff; font-weight: bold; padding: 2px 6px; border-radius: 2px;',
      'color: #065f46; font-weight: 500;'
    );

    // Update worker active task count
    setWorkers((prev) =>
      prev.map((w) => (w.id === workerId ? { ...w, activeTasks: w.activeTasks + 1 } : w))
    );

    // Update asset state to Under Repair
    setAssets((prev) =>
      prev.map((a) => {
        const matchingComplaint = complaints.find((c) => c.id === complaintId);
        if (matchingComplaint && a.id === matchingComplaint.assetId) {
          return { ...a, status: 'Under Repair' };
        }
        return a;
      })
    );

    showToast(
      'Work Order Dispatched!',
      `${worker.name} assigned. Digital work order ${workOrder?.orderId || ''} dispatched.`
    );
  };

  // 3. Worker uploads repair proof
  const handleSubmitRepairProof = (
    complaintId: string,
    proofData: {
      photoUrl: string;
      beforePhotoUrl?: string;
      workerNotes: string;
      partsReplaced: string[];
      geoTag: string;
      actionType?: 'Repair' | 'Replace';
      repairCost?: {
        partsCost: number;
        laborCost: number;
        totalCost: number;
      };
      aiRepairVerification?: {
        verified: boolean;
        confidence: number;
        summary: string;
        inspectedAt: string;
      };
    }
  ) => {
    const completionTimestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: 'Completed',
            repairProof: {
              photoUrl: proofData.photoUrl,
              beforePhotoUrl: proofData.beforePhotoUrl || c.photoUrl,
              completedAt: completionTimestamp,
              workerNotes: proofData.workerNotes,
              partsReplaced: proofData.partsReplaced,
              geoTag: proofData.geoTag,
              contractorVerified: true,
              actionType: proofData.actionType || 'Repair',
              repairCost: proofData.repairCost,
              aiRepairVerification: proofData.aiRepairVerification,
            },
          };
        }
        return c;
      })
    );

    // Also update asset repairHistory with repairProof for instant visual timeline reflection
    setAssets((prev) =>
      prev.map((a) => {
        const matchingComplaint = complaints.find((c) => c.id === complaintId);
        if (matchingComplaint && a.id === matchingComplaint.assetId) {
          return {
            ...a,
            repairHistory: a.repairHistory.map((rec) => {
              if (rec.complaintId === complaintId) {
                return {
                  ...rec,
                  workerName: matchingComplaint.assignedWorker?.name || rec.workerName,
                  partsReplaced: proofData.partsReplaced?.join(', ') || rec.partsReplaced,
                  damagePhotoUrl: matchingComplaint.photoUrl || rec.damagePhotoUrl,
                  costInr: proofData.repairCost?.totalCost || rec.costInr || 1500,
                  repairProof: {
                    photoUrl: proofData.photoUrl,
                    completedAt: completionTimestamp,
                    workerNotes: proofData.workerNotes,
                    partsReplaced: proofData.partsReplaced,
                    geoTag: proofData.geoTag,
                    contractorVerified: true,
                    actionType: proofData.actionType || 'Repair',
                    repairCost: proofData.repairCost,
                    aiRepairVerification: proofData.aiRepairVerification,
                  },
                  galleryPhotos: [
                    ...(rec.galleryPhotos || []),
                    {
                      url: proofData.photoUrl,
                      caption: `Field Repair Completed: ${proofData.workerNotes}`,
                      type: 'repair_proof' as const,
                      timestamp: completionTimestamp,
                      geoTag: proofData.geoTag,
                      capturedBy: matchingComplaint.assignedWorker?.name || 'Assigned Technician',
                    },
                  ],
                };
              }
              return rec;
            }),
          };
        }
        return a;
      })
    );

    showToast(
      'Repair Proof Submitted!',
      'AI QA verified repair evidence. Citizen SMS dispatched for final two-way sign-off.'
    );
  };

  // 4. Citizen verification: FIXED or NOT FIXED
  const handleVerifyDecision = (
    complaintId: string,
    decision: 'Fixed' | 'Not Fixed',
    feedback?: string,
    rating?: number
  ) => {
    const verifiedComplaint = complaints.find((c) => c.id === complaintId);
    if (!verifiedComplaint) return;

    if (decision === 'Fixed') {
      // Mark closed
      setComplaints((prev) =>
        prev.map((c) => {
          if (c.id === complaintId) {
            return {
              ...c,
              status: 'Closed',
              citizenVerification: {
                verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
                decision: 'Fixed',
                feedback,
                rating: rating || 5,
              },
            };
          }
          return c;
        })
      );

      // Update Asset Passport History & Future Failure Prediction
      setAssets((prev) =>
        prev.map((a) => {
          if (a.id === verifiedComplaint.assetId) {
            const nextMtbf = Math.max(90, Math.floor(140 - ((a.failureCount || 1) * 10)));
            const predDate = new Date();
            predDate.setDate(predDate.getDate() + nextMtbf);
            const predictedDateStr = predDate.toISOString().split('T')[0];

            return {
              ...a,
              status: 'Working',
              futureFailurePrediction: {
                predictedFailureDate: predictedDateStr,
                riskScore: 18,
                riskReason: 'Post-repair burn-in phase. Routine load monitoring active.',
                preventiveAction: 'Quarterly sensor diagnostic & terminal cleaning in next cycle.',
                estimatedMtbfDays: nextMtbf,
              },
              repairHistory: a.repairHistory.map((rec) => {
                if (rec.complaintId === complaintId) {
                  return {
                    ...rec,
                    status: 'Closed',
                    resolvedInDays: 1,
                    workerName: verifiedComplaint.assignedWorker?.name || 'Field Lineman',
                    costInr: verifiedComplaint.repairProof?.repairCost?.totalCost || rec.costInr || 1200,
                    partsReplaced: verifiedComplaint.repairProof?.partsReplaced?.join(', ') || 'Inspected and Refurbished',
                  };
                }
                return rec;
              }),
            };
          }
          return a;
        })
      );

      showToast(
        'Case Closed & Verified!',
        'Citizen confirmed repair. Asset Passport history permanently updated with audit stamp.'
      );
    } else {
      // Reopen complaint
      setComplaints((prev) =>
        prev.map((c) => {
          if (c.id === complaintId) {
            return {
              ...c,
              status: 'Reopened',
              reopenCount: (c.reopenCount || 0) + 1,
              citizenVerification: {
                verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
                decision: 'Not Fixed',
                feedback,
              },
            };
          }
          return c;
        })
      );

      showToast(
        'Complaint Reopened!',
        'Citizen rejected repair proof. Case escalated back to Panchayat PDO dashboard.',
        'alert'
      );
    }
  };

  // Reset to original mock data for fresh demos
  const handleResetData = () => {
    localStorage.removeItem('gramsetu_assets');
    localStorage.removeItem('gramsetu_complaints');
    localStorage.removeItem('gramsetu_pdo_alerts');
    setAssets(INITIAL_ASSETS);
    setComplaints(INITIAL_COMPLAINTS);
    setWorkers(INITIAL_WORKERS);

    const initialCritical = INITIAL_COMPLAINTS.find(
      (c) => c.id === 'CMP-2026-101' && c.status === 'Pending'
    );
    if (initialCritical) {
      setPdoAlerts([notifyPdoCriticalGrievance(initialCritical)]);
    } else {
      setPdoAlerts([]);
    }

    showToast('Demo Reset', 'Reset all mock assets, complaints, and timeline records to initial state.');
  };

  const handleDismissAlert = (alertId: string) => {
    setPdoAlerts((prev) => prev.filter((a) => a.id !== alertId));
  };

  const handleNavigateToAssign = (complaintId: string) => {
    setTargetComplaintId(complaintId);
    setActiveRole('panchayat');
    showToast(
      'PDO Command Center Active',
      `Assigned triage view for complaint ${complaintId}. Select certified technician to dispatch.`
    );
  };

  const handleNavigateToAsset = (assetId: string) => {
    setSelectedAssetId(assetId);
    setActiveRole('asset_passport');
  };

  const handleTriggerTestAlert = () => {
    const testComplaint: Complaint = {
      id: `CMP-2026-${Math.floor(200 + Math.random() * 700)}`,
      assetId: 'KA-MYS-WP-018',
      assetName: 'Drinking Water Pipeline #18',
      category: 'Water Supply',
      location: 'Maramma Temple Street, Ward 2',
      ward: 'Ward 2',
      reportedBy: {
        name: 'Smt. Roopa Devi',
        phone: '+91 94481 99210',
        village: 'Belavadi GP',
      },
      reportedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      description: 'Major drinking water pipe rupture flooding temple street. Water pressure zero across Ward 2.',
      descriptionKn: 'ಕುಡಿಯುವ ನೀರಿನ ಪೈಪ್ ಒಡೆದು ರಸ್ತೆಯಲ್ಲಿ ನೀರು ಹರಿಯುತ್ತಿದೆ. ವಾರ್ಡ್ ೨ ರಲ್ಲಿ ನೀರಿನ ಕೊರತೆ.',
      photoUrl: 'https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=800&q=80',
      status: 'Pending',
      priority: 'Critical',
      slaDeadline: new Date(Date.now() + 6 * 3600 * 1000).toISOString(),
      aiTriage: {
        assetType: 'Water Supply',
        damageSeverity: 'Critical',
        recommendedSLA: '6 Hours',
        specialistRequired: 'Plumbing & Hydraulic Technician',
        kannadaTitle: 'ಕುಡಿಯುವ ನೀರಿನ ಪೈಪ್ ಸೋರಿಕೆ - ತುರ್ತು ದುರಸ್ತಿ',
        formalSummaryEn: 'High-pressure pipeline burst at Maramma Temple Street. Urgent valve closure and pipe replacement required to restore drinking water supply.',
        formalSummaryKn: 'ಕುಡಿಯುವ ನೀರಿನ ಪೈಪ್ ಒಡೆದಿದೆ. ತಕ್ಷಣ ಪ್ಲಂಬರ್ ನಿಯೋಜನೆ ಅಗತ್ಯ.',
        hazardWarning: 'Severe water wastage & road flooding. Risk of road sinkage and water supply shutdown.',
        suggestedAction: 'Isolate Ward 2 distribution valve, dispatch Ramesh Gowda (Plumber), replace 100mm PVC union socket.',
      },
    };
    handleCreateComplaint(testComplaint);
  };

  const safeComplaints = complaints || [];
  const pendingVerificationsCount = safeComplaints.filter((c) => c.status === 'Completed').length;
  const unassignedComplaintsCount = safeComplaints.filter((c) => c.status === 'Pending').length;
  const assignedTasksCount = safeComplaints.filter(
    (c) =>
      (c.status === 'Assigned' || c.status === 'In Progress') &&
      (!c.assignedWorker || c.assignedWorker.id === currentWorkerId)
  ).length;

  return (
    <div className={`min-h-screen ${currentTheme.classes.appBg} ${currentTheme.classes.textPrimary} flex flex-col font-['Plus_Jakarta_Sans',sans-serif] transition-colors duration-300`}>
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 max-w-sm w-full animate-in fade-in slide-in-from-top-4 duration-300">
          <div
            className={`p-4 rounded-2xl shadow-xl border flex items-start space-x-3 ${
              toastMessage.type === 'alert'
                ? 'bg-red-50 border-red-200 text-red-950'
                : 'bg-emerald-50 border-emerald-200 text-emerald-950'
            }`}
          >
            {toastMessage.type === 'alert' ? (
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div className="text-xs">
              <div className="font-extrabold">{toastMessage.title}</div>
              <div className="text-slate-600 font-medium mt-0.5 leading-relaxed">{toastMessage.desc}</div>
            </div>
          </div>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        activeRole={activeRole}
        onRoleChange={setActiveRole}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'en' ? 'kn' : 'en'))}
        pendingVerificationsCount={pendingVerificationsCount}
        unassignedComplaintsCount={unassignedComplaintsCount}
        assignedTasksCount={assignedTasksCount}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        theme={currentTheme}
      />

      {/* Persistent PDO Automated Notification Banner for Critical Grievances */}
      {activeRole === 'panchayat' && (
        <PdoNotificationBanner
          alerts={pdoAlerts}
          onDismissAlert={handleDismissAlert}
          onNavigateToAssign={handleNavigateToAssign}
          onNavigateToAsset={handleNavigateToAsset}
          lang={lang}
          onTriggerTestAlert={handleTriggerTestAlert}
        />
      )}

      {/* Main Role-Based Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeRole === 'citizen' && (
          <CitizenHome
            complaints={complaints}
            onOpenReportModal={() => setIsReportModalOpen(true)}
            onOpenVerifyModal={(comp) => setVerifyComplaintTarget(comp)}
            lang={lang}
            theme={currentTheme}
          />
        )}

        {activeRole === 'panchayat' && (
          <PanchayatDashboard
            complaints={complaints}
            workers={workers}
            assets={assets}
            targetComplaintId={targetComplaintId}
            onAssignWorker={handleAssignWorker}
            onSelectAssetPassport={(assetId) => {
              setSelectedAssetId(assetId);
              setActiveRole('asset_passport');
            }}
            lang={lang}
          />
        )}

        {activeRole === 'worker' && (
          <WorkerDashboard
            complaints={complaints}
            workers={workers}
            currentWorkerId={currentWorkerId}
            onSelectWorker={setCurrentWorkerId}
            onSubmitRepairProof={handleSubmitRepairProof}
            lang={lang}
          />
        )}

        {activeRole === 'asset_passport' && (
          <AssetPassportView
            assets={assets}
            complaints={complaints}
            selectedAssetId={selectedAssetId}
            onSelectAsset={setSelectedAssetId}
            lang={lang}
          />
        )}

        {activeRole === 'analytics' && (
          <AnalyticsDashboard
            assets={assets}
            complaints={complaints}
            lang={lang}
            onSelectAsset={(assetId) => {
              setSelectedAssetId(assetId);
              setActiveRole('asset_passport');
            }}
          />
        )}
      </main>

      {/* Official Government of Karnataka Footer with Contact Details & Social Handles */}
      <Footer lang={lang} theme={currentTheme} />

      {/* Modal 1: Report Issue */}
      <CitizenReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onSubmit={handleCreateComplaint}
        lang={lang}
        assets={assets}
        complaints={complaints}
      />

      {/* Modal 2: Verify Repair Proof */}
      <CitizenVerifyModal
        isOpen={Boolean(verifyComplaintTarget)}
        complaint={verifyComplaintTarget}
        onClose={() => setVerifyComplaintTarget(null)}
        onVerifyDecision={handleVerifyDecision}
        lang={lang}
      />

      {/* Modal 3: Judge Guided Demo Flow */}
      <GuidedDemoModal
        isOpen={isDemoFlowOpen}
        onClose={() => setIsDemoFlowOpen(false)}
        onSelectRole={setActiveRole}
        lang={lang}
      />

      {/* Modal 4: Hackathon Developer Hub & Source Code Exporter */}
      <HackathonDevHubModal
        isOpen={isDevHubOpen}
        onClose={() => setIsDevHubOpen(false)}
      />
    </div>
  );
}
