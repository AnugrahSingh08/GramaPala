import React, { useState } from 'react';
import { ActiveRole, LanguageMode } from '../types';
import { 
  GitCommit, 
  Camera, 
  Sparkles, 
  MapPin, 
  Search, 
  RefreshCw, 
  BarChart2, 
  Send, 
  Ticket, 
  Building2, 
  FileText, 
  Scale, 
  ClipboardList, 
  Wrench, 
  DollarSign, 
  ShieldCheck, 
  UserCheck, 
  CheckCircle2, 
  Database, 
  BrainCircuit, 
  Layers,
  ChevronRight,
  ChevronDown,
  Info
} from 'lucide-react';

interface FlowchartNavigatorProps {
  activeRole: ActiveRole;
  onSelectRole: (role: ActiveRole) => void;
  onOpenReportModal: () => void;
  lang: LanguageMode;
}

export const FLOWCHART_STEPS = [
  { id: 'citizen', phase: 'Citizen Grievance Capture', label: 'CITIZEN', icon: UserCheck, role: 'citizen' as ActiveRole },
  { id: 'photo', phase: 'Citizen Grievance Capture', label: '📷 Take Photo', icon: Camera, role: 'citizen' as ActiveRole },
  { id: 'ai_detect', phase: 'Citizen Grievance Capture', label: '🤖 AI Detect Asset + Problem', icon: Sparkles, role: 'citizen' as ActiveRole },
  { id: 'gps', phase: 'Citizen Grievance Capture', label: '📍 GPS Geotagging', icon: MapPin, role: 'citizen' as ActiveRole },
  { id: 'find_asset', phase: 'Registry Matching', label: '🔎 Find Existing Asset', icon: Search, role: 'citizen' as ActiveRole },
  { id: 'duplicate', phase: 'Registry Matching', label: '🔄 Duplicate Detection', icon: RefreshCw, role: 'citizen' as ActiveRole },
  { id: 'impact_score', phase: 'Priority Scoring', label: '📊 Community Impact Score', icon: BarChart2, role: 'citizen' as ActiveRole },
  { id: 'submit', phase: 'Dispatch', label: '📤 Submit Grievance', icon: Send, role: 'citizen' as ActiveRole },
  { id: 'complaint_id', phase: 'Dispatch', label: '🎫 Complaint ID & Receipt', icon: Ticket, role: 'citizen' as ActiveRole },
  { id: 'panchayat', phase: 'PDO Command Center', label: '🏛️ PANCHAYAT DASHBOARD', icon: Building2, role: 'panchayat' as ActiveRole },
  { id: 'asset_history', phase: 'PDO Command Center', label: '📋 Asset History Audit', icon: FileText, role: 'asset_passport' as ActiveRole },
  { id: 'repair_vs_replace', phase: 'Lifecycle Intelligence', label: '🤖 Repair vs Replace Recommendation', icon: Scale, role: 'panchayat' as ActiveRole },
  { id: 'work_order', phase: 'Field Dispatch', label: '📝 Digital Work Order', icon: ClipboardList, role: 'panchayat' as ActiveRole },
  { id: 'field_worker', phase: 'Technician Execution', label: '👷 FIELD WORKER', icon: Wrench, role: 'worker' as ActiveRole },
  { id: 'before_photo', phase: 'Technician Execution', label: '📷 Before Photo', icon: Camera, role: 'worker' as ActiveRole },
  { id: 'action', phase: 'Technician Execution', label: '🔧 Repair / Replace Action', icon: Wrench, role: 'worker' as ActiveRole },
  { id: 'cost_entry', phase: 'Technician Execution', label: '💰 Cost Entry (Parts + Labor)', icon: DollarSign, role: 'worker' as ActiveRole },
  { id: 'after_photo', phase: 'Technician Execution', label: '📷 After Photo', icon: Camera, role: 'worker' as ActiveRole },
  { id: 'ai_verify', phase: 'Quality Assurance', label: '🤖 AI Visual Verification', icon: ShieldCheck, role: 'worker' as ActiveRole },
  { id: 'citizen_verify', phase: 'Two-Way Citizen Sign-Off', label: '👤 CITIZEN VERIFICATION', icon: UserCheck, role: 'citizen' as ActiveRole },
  { id: 'resolved', phase: 'Two-Way Citizen Sign-Off', label: '✅ RESOLVED & CLOSED', icon: CheckCircle2, role: 'citizen' as ActiveRole },
  { id: 'asset_updated', phase: 'Permanent Passport Ledger', label: '🧠 ASSET HISTORY UPDATED', icon: Database, role: 'asset_passport' as ActiveRole },
  { id: 'future_prediction', phase: 'Predictive Intelligence', label: '🔮 FUTURE FAILURE PREDICTION', icon: BrainCircuit, role: 'analytics' as ActiveRole },
  { id: 'planning', phase: 'Panchayat Governance', label: '🏛️ PANCHAYAT PLANNING & BUDGET', icon: Layers, role: 'analytics' as ActiveRole },
];

export const FlowchartNavigator: React.FC<FlowchartNavigatorProps> = ({
  activeRole,
  onSelectRole,
  onOpenReportModal,
  lang,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  return (
    <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-amber-500/30 rounded-2xl p-3.5 sm:p-4 text-white shadow-xl mb-6 relative overflow-hidden">
      {/* Decorative ambient background */}
      <div className="absolute top-0 right-0 w-80 h-32 bg-amber-500/10 blur-3xl rounded-full pointer-events-none" />
      
      {/* Header with expand toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 relative z-10">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-bold shrink-0">
            <GitCommit className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-xs sm:text-sm font-black tracking-tight text-white flex items-center gap-1.5">
                <span>GovTech Governance Flowchart</span>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-400 text-slate-950">
                  24-Stage End-to-End
                </span>
              </h3>
            </div>
            <p className="text-[11px] text-slate-300 font-medium">
              {lang === 'kn' 
                ? 'ನಾಗರಿಕ ದೂರಿನಿಂದ ಹಿಡಿದು ಎಐ ಪರಿಶೀಲನೆ ಮತ್ತು ಪಂಚಾಯತ್ ಯೋಜನೆಯವರೆಗೆ ಸಂಪೂರ್ಣ ಹಂತಗಳು'
                : 'From Citizen Photo to AI Triage, Work Order, Verification & Failure Prediction'}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={onOpenReportModal}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-3 py-1.5 rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Launch Citizen Photo Flow</span>
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center space-x-1 bg-white/10 hover:bg-white/20 text-white font-bold px-2.5 py-1.5 rounded-xl text-xs border border-white/20 transition-all cursor-pointer"
          >
            <span>{isExpanded ? 'Hide Flowchart' : 'View Full Flowchart'}</span>
            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Quick Summary Pill Bar */}
      <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px] font-bold">
        <span className="text-amber-400 shrink-0">Core Cycle:</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          1. Citizen 📷 Photo + 🤖 AI Triage
        </span>
        <span className="text-amber-400">→</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          2. 📍 GPS + 🔎 Registry Match + 🔄 Duplicate Check
        </span>
        <span className="text-amber-400">→</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          3. 🏛️ PDO 📋 Asset History + 🤖 Repair/Replace + 📝 Work Order
        </span>
        <span className="text-amber-400">→</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          4. 👷 Worker 📷 Before/After + 💰 Cost + 🤖 AI Verification
        </span>
        <span className="text-amber-400">→</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          5. 👤 Citizen Sign-off → ✅ Resolved
        </span>
        <span className="text-amber-400">→</span>
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-white border border-white/10 whitespace-nowrap">
          6. 🧠 Asset Updated → 🔮 Prediction → 🏛️ Planning
        </span>
      </div>

      {/* Expanded Interactive 24-Stage Stepper View */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-white/15 animate-in fade-in slide-in-from-top-3 duration-300">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {FLOWCHART_STEPS.map((step, index) => {
              const isCurrentRole = activeRole === step.role;
              return (
                <button
                  key={step.id}
                  onClick={() => onSelectRole(step.role)}
                  className={`p-2 rounded-xl text-left transition-all border cursor-pointer relative group ${
                    isCurrentRole
                      ? 'bg-amber-400/20 border-amber-400 text-amber-200 shadow-md ring-1 ring-amber-400/40'
                      : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span className="font-mono font-bold">#{index + 1}</span>
                    <span className="text-[9px] uppercase px-1 rounded bg-white/10">{step.role}</span>
                  </div>
                  <div className="text-xs font-bold leading-tight line-clamp-2">
                    {step.label}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
