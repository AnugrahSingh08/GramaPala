import React from 'react';
import { ActiveRole, LanguageMode } from '../types';
import { 
  PlayCircle, 
  X, 
  ArrowRight, 
  CheckCircle2, 
  User, 
  Building2, 
  Wrench, 
  ShieldCheck, 
  FileText,
  Sparkles,
  Zap
} from 'lucide-react';

interface GuidedDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: ActiveRole) => void;
  onRunSimulationStep?: (stepIndex: number) => void;
  lang: LanguageMode;
}

const DEMO_STEPS = [
  {
    step: 1,
    title: 'Citizen Reports Damaged Asset',
    titleKn: '೧. ನಾಗರಿಕರು ಹಾನಿಯ ದೂರು ನೀಡುತ್ತಾರೆ',
    role: 'citizen' as ActiveRole,
    icon: User,
    color: 'from-red-600 to-amber-600',
    description: 'Citizen snaps a photo of broken streetlight SL-102 in Ward 3. Gemini AI auto-detects severity & drafts work order with Kannada translation.',
    actionLabel: 'Switch to Citizen View',
  },
  {
    step: 2,
    title: 'Panchayat Triage & Worker Assignment',
    titleKn: '೨. ಪಂಚಾಯತ್ ಅಧಿಕಾರಿಗಳು ಕರ್ಮಿಕರನ್ನು ನಿಯೋಜಿಸುತ್ತಾರೆ',
    role: 'panchayat' as ActiveRole,
    icon: Building2,
    color: 'from-indigo-600 to-blue-600',
    description: 'Automated PDO notification banner triggers via SMS/WhatsApp telemetry & console logs. Panchayat PDO inspects AI severity and dispatches certified field lineman Basavaraju.',
    actionLabel: 'Switch to Panchayat View',
  },
  {
    step: 3,
    title: 'Worker Field Repair & Geotagged Proof',
    titleKn: '೩. ಕರ್ಮಿಕರು ದುರಸ್ತಿ ಮಾಡಿ ಫೋಟೋ ಪುರಾವೆ ಅಪ್‌ಲೋಡ್ ಮಾಡುತ್ತಾರೆ',
    role: 'worker' as ActiveRole,
    icon: Wrench,
    color: 'from-emerald-600 to-teal-600',
    description: 'Field lineman replaces burnt LED driver, records replaced parts, and uploads geotagged repair proof photo.',
    actionLabel: 'Switch to Worker View',
  },
  {
    step: 4,
    title: 'Citizen Two-Way Verification (Two-Way Lock)',
    titleKn: '೪. ನಾಗರಿಕರು ಫೋಟೋ ಪರಿಶೀಲಿಸಿ ಮುಕ್ತಾಯಗೊಳಿಸುತ್ತಾರೆ',
    role: 'citizen' as ActiveRole,
    icon: ShieldCheck,
    color: 'from-amber-600 to-emerald-600',
    description: 'Citizen receives SMS alert, inspects Before vs After photo comparison, and clicks "Fixed". Case closed only upon citizen sign-off!',
    actionLabel: 'Open Citizen Verification',
  },
  {
    step: 5,
    title: 'Asset Passport & Lemon Asset Audit',
    titleKn: '೫. ಆಸ್ತಿ ಪಾಸ್‌ಪೋರ್ಟ್ ಮತ್ತು ಲೆಮನ್ ಆಸ್ತಿ ಪರಿಶೋಧನೆ',
    role: 'asset_passport' as ActiveRole,
    icon: FileText,
    color: 'from-purple-600 to-indigo-600',
    description: 'Streetlight SL-102 digital passport logs lifetime repair record. If 3+ breakdowns occur, Lemon Asset alert penalizes contractor under warranty.',
    actionLabel: 'Open Asset Passport',
  },
];

export const GuidedDemoModal: React.FC<GuidedDemoModalProps> = ({
  isOpen,
  onClose,
  onSelectRole,
  lang,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center font-black shadow-xs">
              <PlayCircle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  Interactive Grievance Redressal Lifecycle
                </h2>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-amber-300">
                  5-Step Lifecycle
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {lang === 'kn'
                  ? 'ದೂರು ಸಲ್ಲಿಕೆಯಿಂದ ಆಸ್ತಿ ಪಾಸ್‌ಪೋರ್ಟ್ ನವೀಕರಣದವರೆಗಿನ ಸಂಪೂರ್ಣ ಹರಿವು'
                  : 'Demonstrating the exact end-to-end flow from problem statement (Pages 1-6)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Developer One-Line Flow Banner from PDF Page 6 */}
        <div className="my-4 bg-slate-900 text-white p-3.5 rounded-2xl text-xs font-mono font-medium flex items-center space-x-2 border border-slate-800">
          <Zap className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="leading-relaxed">
            <span className="text-amber-300 font-bold">One-Line Flow:</span> Citizen reports issue ➔ Panchayat assigns worker ➔ Worker uploads repair proof ➔ Citizen verifies repair ➔ Asset history gets updated.
          </div>
        </div>

        {/* 5 Steps Interactive List */}
        <div className="space-y-2.5 max-h-[55vh] overflow-y-auto pr-1">
          {DEMO_STEPS.map((step) => {
            const IconComponent = step.icon;
            return (
              <div
                key={step.step}
                className="bg-slate-50 hover:bg-slate-100/80 transition-all p-3.5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="flex items-start space-x-3">
                  <div
                    className={`w-9 h-9 rounded-xl bg-gradient-to-br ${step.color} text-white flex items-center justify-center font-black shrink-0 text-xs shadow-xs`}
                  >
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-black uppercase text-slate-400">
                        Step {step.step}
                      </span>
                      <h4 className="text-xs font-black text-slate-900">
                        {lang === 'kn' ? step.titleKn : step.title}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed max-w-md">
                      {step.description}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onSelectRole(step.role);
                    onClose();
                  }}
                  className="flex items-center space-x-1.5 bg-white hover:bg-slate-900 hover:text-white text-slate-800 border border-slate-300 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs shrink-0 cursor-pointer self-end sm:self-center"
                >
                  <span>{step.actionLabel}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>

        <div className="pt-4 mt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
          <span>GovTech Karnataka LEAP 2026-27</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white rounded-xl font-bold cursor-pointer hover:bg-slate-800"
          >
            Close Flow
          </button>
        </div>
      </div>
    </div>
  );
};
