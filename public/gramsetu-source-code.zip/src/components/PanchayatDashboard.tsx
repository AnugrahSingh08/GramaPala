import React, { useState, useMemo, useEffect } from 'react';
import { Complaint, WorkerInfo, LanguageMode, Asset, WorkOrder } from '../types';
import { 
  Search, 
  UserCheck, 
  AlertCircle, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  ShieldAlert, 
  Wrench, 
  Phone, 
  Zap,
  X,
  FileText,
  Scale,
  ClipboardList,
  Sparkles,
  ArrowRight,
  DollarSign,
  Building2,
  Calendar,
  Check
} from 'lucide-react';

interface PanchayatDashboardProps {
  complaints: Complaint[];
  workers: WorkerInfo[];
  assets: Asset[];
  onAssignWorker: (complaintId: string, workerId: string, workOrder?: WorkOrder) => void;
  onSelectAssetPassport: (assetId: string) => void;
  lang: LanguageMode;
  targetComplaintId?: string | null;
}

export const PanchayatDashboard: React.FC<PanchayatDashboardProps> = ({
  complaints = [],
  workers = [],
  assets = [],
  onAssignWorker,
  onSelectAssetPassport,
  lang,
  targetComplaintId,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('actionable');
  const [wardFilter, setWardFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>((complaints && complaints[0]) || null);
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>((workers && workers[0]?.id) || '');
  const [isAssignModalOpen, setIsAssignModalOpen] = useState<boolean>(false);

  // Work order configuration states
  const [workOrderActionType, setWorkOrderActionType] = useState<'Repair' | 'Replace'>('Repair');
  const [authorizedBudget, setAuthorizedBudget] = useState<number>(2400);
  const [targetSlaHours, setTargetSlaHours] = useState<number>(24);
  const [workOrderNotes, setWorkOrderNotes] = useState<string>('Inspect component failure, replace defective parts with certified spares, and upload geo-stamped repair proof.');

  // Memoized task metrics
  const metrics = useMemo(() => {
    const list = complaints || [];
    const total = list.length;
    const pending = list.filter((c) => c.status === 'Pending').length;
    const inProgress = list.filter((c) => c.status === 'Assigned' || c.status === 'In Progress').length;
    const awaitingVerify = list.filter((c) => c.status === 'Completed').length;
    const closed = list.filter((c) => c.status === 'Closed').length;
    const reopened = list.filter((c) => c.status === 'Reopened').length;
    return { total, pending, inProgress, awaitingVerify, closed, reopened };
  }, [complaints]);

  // Synchronize targeted or updated complaint
  useEffect(() => {
    if (targetComplaintId) {
      const match = complaints.find((c) => c.id === targetComplaintId);
      if (match) {
        setSelectedComplaint(match);
        if (statusFilter !== 'all' && statusFilter !== match.status && statusFilter !== 'actionable') {
          setStatusFilter('all');
        }
        return;
      }
    }
    if (selectedComplaint) {
      const current = complaints.find((c) => c.id === selectedComplaint.id);
      if (current) {
        setSelectedComplaint(current);
        return;
      }
    }
    if (complaints.length > 0) {
      setSelectedComplaint(complaints[0]);
    }
  }, [targetComplaintId, complaints]);

  // Priority sort: actionable items first
  const priorityOrder: Record<string, number> = {
    Pending: 1,
    Reopened: 2,
    Assigned: 3,
    'In Progress': 4,
    Completed: 5,
    Closed: 6,
  };

  const filteredComplaints = useMemo(() => {
    return complaints
      .filter((c) => {
        if (statusFilter === 'actionable') {
          return c.status === 'Pending' || c.status === 'Reopened';
        }
        if (statusFilter === 'Assigned') {
          return c.status === 'Assigned' || c.status === 'In Progress';
        }
        if (statusFilter !== 'all' && c.status !== statusFilter) return false;
        if (wardFilter !== 'all' && c.ward !== wardFilter) return false;
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          return (
            c.id.toLowerCase().includes(q) ||
            c.assetName.toLowerCase().includes(q) ||
            c.location.toLowerCase().includes(q) ||
            c.category.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        const pA = priorityOrder[a.status] || 99;
        const pB = priorityOrder[b.status] || 99;
        return pA - pB;
      });
  }, [complaints, statusFilter, wardFilter, searchQuery]);

  // Matched asset for currently selected complaint
  const matchedAsset = useMemo(() => {
    if (!selectedComplaint) return null;
    return assets.find((a) => a.id === selectedComplaint.assetId) || assets[0];
  }, [selectedComplaint, assets]);

  // Calculate AI Repair vs Replace recommendation
  const repairVsReplaceRecommendation = useMemo(() => {
    if (!matchedAsset) {
      return {
        recommendation: 'Repair' as const,
        justification: 'Standard component servicing recommended.',
        savings: 3500,
        action: 'Repair',
      };
    }
    const isLemon = matchedAsset.isLemonAsset || matchedAsset.failureCount >= 3;
    const isWarranty = matchedAsset.isUnderWarranty;

    if (isLemon) {
      return {
        recommendation: 'Replace' as const,
        justification: `Asset ${matchedAsset.id} has broken down ${matchedAsset.failureCount} times. ${
          isWarranty ? 'Contractor warranty clause is active: claim free full unit replacement.' : 'Cumulative repair exceeds unit value. Recommend capital replacement under 15th FC grants.'
        }`,
        savings: isWarranty ? 14500 : 7200,
        action: 'Replace',
      };
    }
    return {
      recommendation: 'Repair' as const,
      justification: 'Minor isolated component failure. Component repair is 78% cheaper than asset retirement.',
      savings: 4200,
      action: 'Repair',
    };
  }, [matchedAsset]);

  const handleOpenAssign = (complaint: Complaint) => {
    setSelectedComplaint(complaint);
    // Auto-select appropriate worker by trade
    const matchedWorker = workers.find((w) => {
      if (complaint.category === 'Streetlight' && w.trade.toLowerCase().includes('lineman')) return true;
      if (complaint.category.includes('Water') && w.trade.toLowerCase().includes('plumb')) return true;
      if (complaint.category.includes('Road') && w.trade.toLowerCase().includes('civil')) return true;
      return false;
    });
    if (matchedWorker) setSelectedWorkerId(matchedWorker.id);
    
    // Set recommended action type
    setWorkOrderActionType(repairVsReplaceRecommendation.recommendation);
    setAuthorizedBudget(repairVsReplaceRecommendation.recommendation === 'Replace' ? 7500 : 2200);
    setIsAssignModalOpen(true);
  };

  const handleConfirmAssign = () => {
    if (!selectedComplaint || !selectedWorkerId) return;
    
    const workOrder: WorkOrder = {
      orderId: `WO-2026-MYS-${Math.floor(100 + Math.random() * 900)}`,
      issuedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      authorizedBudget: authorizedBudget,
      actionType: workOrderActionType,
      targetSla: `${targetSlaHours} Hours`,
      pdoApprovalSignature: 'M. S. Patil (Belavadi PDO)',
      instructions: workOrderNotes,
    };

    onAssignWorker(selectedComplaint.id, selectedWorkerId, workOrder);
    setIsAssignModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top PDO Command Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-black uppercase tracking-wider text-slate-500">
              Karnataka Panchayat Raj Digital Console
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 mt-0.5">
            {lang === 'kn' ? 'ಬೆಳವಡಿ ಗ್ರಾಮ ಪಂಚಾಯತ್ - ಪಿ.ಡಿ.ಒ ಕಾರ್ಯನಿರ್ವಾಹಕ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್' : 'Belavadi Gram Panchayat — PDO Work Order Desk'}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Review citizen grievances, inspect asset lifecycle history, and dispatch authorized work orders to field technicians.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-amber-50 border border-amber-300 px-3 py-1.5 rounded-2xl text-xs font-bold text-amber-900 flex items-center space-x-2">
            <Scale className="w-4 h-4 text-amber-600" />
            <span>AI Lifecycle Decision Active</span>
          </div>
        </div>
      </div>

      {/* Metric Counters Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => setStatusFilter('actionable')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'actionable'
              ? 'bg-red-50 border-red-300 ring-2 ring-red-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-red-700">Action Required</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.pending + metrics.reopened}</div>
          <div className="text-[10px] text-slate-400 font-medium">Needs Work Order</div>
        </button>

        <button
          onClick={() => setStatusFilter('Pending')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Pending'
              ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-amber-700">New Grievances</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.pending}</div>
          <div className="text-[10px] text-slate-400 font-medium">Pending Triage</div>
        </button>

        <button
          onClick={() => setStatusFilter('Assigned')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Assigned'
              ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-blue-700">Work Orders Active</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.inProgress}</div>
          <div className="text-[10px] text-slate-400 font-medium">Field Linemen Dispatched</div>
        </button>

        <button
          onClick={() => setStatusFilter('Completed')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Completed'
              ? 'bg-purple-50 border-purple-300 ring-2 ring-purple-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-purple-700">Proof Submitted</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.awaitingVerify}</div>
          <div className="text-[10px] text-slate-400 font-medium">Awaiting Citizen Check</div>
        </button>

        <button
          onClick={() => setStatusFilter('Closed')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Closed'
              ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-emerald-700">Resolved & Closed</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.closed}</div>
          <div className="text-[10px] text-slate-400 font-medium">Passport Updated</div>
        </button>

        <button
          onClick={() => setStatusFilter('all')}
          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-slate-100 border-slate-400 ring-2 ring-slate-400'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-[11px] font-bold text-slate-700">Total Lifecycle</div>
          <div className="text-xl font-black text-slate-900 mt-0.5">{metrics.total}</div>
          <div className="text-[10px] text-slate-400 font-medium">All Grievances</div>
        </button>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Complaints Feed (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            {/* Filter toolbar */}
            <div className="p-3.5 border-b border-slate-100 flex flex-wrap gap-2.5 items-center justify-between">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search grievance ID, asset, ward..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <select
                value={wardFilter}
                onChange={(e) => setWardFilter(e.target.value)}
                className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
              >
                <option value="all">All Wards</option>
                <option value="Ward 1">Ward 1</option>
                <option value="Ward 2">Ward 2</option>
                <option value="Ward 3">Ward 3</option>
                <option value="Ward 4">Ward 4</option>
              </select>
            </div>

            {/* List */}
            <div className="divide-y divide-slate-100 max-h-[620px] overflow-y-auto">
              {filteredComplaints.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No grievances found matching this filter.
                </div>
              ) : (
                filteredComplaints.map((c) => {
                  const isSelected = selectedComplaint?.id === c.id;
                  const isActionable = c.status === 'Pending' || c.status === 'Reopened';

                  return (
                    <div
                      key={c.id}
                      onClick={() => setSelectedComplaint(c)}
                      className={`p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 ${
                        isSelected ? 'bg-amber-50/50 border-l-4 border-amber-600' : ''
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <img
                          src={c.photoUrl}
                          alt="Grievance thumbnail"
                          className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="space-y-0.5">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-mono font-black text-indigo-700">{c.id}</span>
                            <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                              {c.category}
                            </span>
                            <span className="text-[10px] text-slate-500 font-bold">{c.ward}</span>
                            {c.communityImpactScore && (
                              <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-purple-100 text-purple-800">
                                Impact {c.communityImpactScore}
                              </span>
                            )}
                          </div>
                          <h4 className="text-xs font-black text-slate-900 leading-snug">{c.assetName}</h4>
                          <p className="text-[11px] text-slate-500 line-clamp-1">{c.location}</p>
                        </div>
                      </div>

                      <div className="text-right space-y-1.5 shrink-0 flex flex-col items-end">
                        <span
                          className={`inline-block text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                            c.status === 'Pending'
                              ? 'bg-red-100 text-red-800'
                              : c.status === 'Assigned' || c.status === 'In Progress'
                              ? 'bg-blue-100 text-blue-800'
                              : c.status === 'Completed'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {c.status}
                        </span>

                        {isActionable ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenAssign(c);
                            }}
                            className="flex items-center space-x-1 bg-amber-600 hover:bg-amber-700 text-white px-2.5 py-1 rounded-lg text-[10px] font-black shadow-xs transition-all cursor-pointer"
                          >
                            <ClipboardList className="w-3 h-3" />
                            <span>Work Order</span>
                          </button>
                        ) : (
                          <div className="text-[10px] text-slate-400 font-medium">
                            {c.workOrder?.orderId || 'SLA 24h'}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right: Selected Grievance, 📋 Asset History & 🤖 Repair vs Replace Recommendation (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {selectedComplaint ? (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4 sticky top-20">
              {/* Header */}
              <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-black text-indigo-700">{selectedComplaint.id}</span>
                    <span
                      className={`text-[10px] font-extrabold px-2 py-0.2 rounded-full uppercase ${
                        selectedComplaint.status === 'Pending'
                          ? 'bg-red-100 text-red-800'
                          : selectedComplaint.status === 'Completed'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {selectedComplaint.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-black text-slate-900 mt-1">{selectedComplaint.assetName}</h3>
                </div>

                <button
                  onClick={() => onSelectAssetPassport(selectedComplaint.assetId)}
                  className="text-[11px] font-bold text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-xl transition-colors cursor-pointer border border-amber-200"
                >
                  View Full Passport ➔
                </button>
              </div>

              {/* Photo & Reporter Info */}
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 h-40">
                <img
                  src={selectedComplaint.photoUrl}
                  alt="Grievance Photo"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-3 text-white text-xs">
                  <div className="font-bold flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5 text-amber-300" />
                    <span>{selectedComplaint.location}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 mt-0.5">
                    Reported by: {selectedComplaint.reportedBy.name} ({selectedComplaint.reportedBy.phone})
                  </div>
                </div>
              </div>

              {/* 📋 Step: Asset History Audit */}
              {matchedAsset && (
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-slate-800 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-amber-600" />
                      <span>📋 Asset Passport History</span>
                    </span>
                    <span className="font-mono text-[11px] text-indigo-700 font-bold">{matchedAsset.id}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center pt-1">
                    <div className="p-2 rounded-xl bg-white border border-slate-200">
                      <div className="text-[10px] text-slate-500 font-semibold">Breakdowns</div>
                      <div className={`font-black text-sm ${matchedAsset.failureCount >= 3 ? 'text-red-700' : 'text-slate-800'}`}>
                        {matchedAsset.failureCount} Failures
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-white border border-slate-200">
                      <div className="text-[10px] text-slate-500 font-semibold">Warranty</div>
                      <div className="font-black text-sm text-emerald-700">
                        {matchedAsset.isUnderWarranty ? 'Active' : 'Expired'}
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-white border border-slate-200">
                      <div className="text-[10px] text-slate-500 font-semibold">Prior Repairs</div>
                      <div className="font-black text-sm text-indigo-700">
                        ₹{matchedAsset.repairHistory.reduce((sum, r) => sum + (r.costInr || 0), 0)}
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-600 pt-0.5">
                    Installed: <span className="font-semibold">{matchedAsset.installationDate}</span> by{' '}
                    <span className="font-semibold text-slate-800">{matchedAsset.contractor}</span>
                  </div>
                </div>
              )}

              {/* 🤖 Step: Repair vs Replace Recommendation */}
              <div className="bg-gradient-to-br from-amber-50/80 via-white to-indigo-50/80 p-3.5 rounded-2xl border border-amber-300 shadow-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 text-xs font-black text-slate-900">
                    <Scale className="w-4 h-4 text-amber-600" />
                    <span>🤖 AI Repair vs Replace Recommendation</span>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    repairVsReplaceRecommendation.recommendation === 'Replace'
                      ? 'bg-red-100 text-red-800 border border-red-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}>
                    {repairVsReplaceRecommendation.recommendation}
                  </span>
                </div>

                <p className="text-xs text-slate-700 font-medium leading-relaxed">
                  {repairVsReplaceRecommendation.justification}
                </p>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                  <span className="text-slate-500 font-semibold">Public Fund Savings:</span>
                  <span className="font-black text-emerald-700">
                    Est. ₹{repairVsReplaceRecommendation.savings.toLocaleString('en-IN')} Saved
                  </span>
                </div>
              </div>

              {/* Work Order Action Button */}
              {selectedComplaint.status === 'Pending' || selectedComplaint.status === 'Reopened' ? (
                <button
                  onClick={() => handleOpenAssign(selectedComplaint)}
                  className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-amber-600 to-indigo-700 hover:from-amber-700 hover:to-indigo-800 text-white py-3 px-4 rounded-2xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  <ClipboardList className="w-4 h-4" />
                  <span>Issue Digital Work Order & Assign Technician</span>
                </button>
              ) : selectedComplaint.workOrder ? (
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-2xl text-xs space-y-1">
                  <div className="flex items-center justify-between font-black text-blue-950">
                    <span>Work Order: {selectedComplaint.workOrder.orderId}</span>
                    <span className="px-2 py-0.2 rounded bg-blue-200 text-blue-900 uppercase text-[10px]">
                      {selectedComplaint.workOrder.actionType}
                    </span>
                  </div>
                  <div className="text-slate-600 text-[11px]">
                    Authorized Budget: ₹{selectedComplaint.workOrder.authorizedBudget} • Target SLA: {selectedComplaint.workOrder.targetSla}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Signed by: {selectedComplaint.workOrder.pdoApprovalSignature}
                  </div>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-slate-400">
              Select a complaint from the left to view asset history and issue work orders.
            </div>
          )}
        </div>
      </div>

      {/* 📝 Step: Digital Work Order Modal */}
      {isAssignModalOpen && selectedComplaint && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    Issue Digital Work Order: {selectedComplaint.id}
                  </h3>
                  <p className="text-xs text-slate-500">{selectedComplaint.assetName}</p>
                </div>
              </div>
              <button
                onClick={() => setIsAssignModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3.5 pt-3">
              {/* Action Type & Budget */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Action Type (AI Guided)
                  </label>
                  <select
                    value={workOrderActionType}
                    onChange={(e) => setWorkOrderActionType(e.target.value as 'Repair' | 'Replace')}
                    className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Repair">Repair / Component Servicing</option>
                    <option value="Replace">Complete Unit Replacement</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Authorized Budget (₹)
                  </label>
                  <input
                    type="number"
                    value={authorizedBudget}
                    onChange={(e) => setAuthorizedBudget(Number(e.target.value))}
                    className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Target SLA */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target SLA Completion Window
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[12, 24, 48].map((hrs) => (
                    <button
                      key={hrs}
                      type="button"
                      onClick={() => setTargetSlaHours(hrs)}
                      className={`py-1.5 text-xs font-black rounded-xl border cursor-pointer transition-all ${
                        targetSlaHours === hrs
                          ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {hrs} Hours
                    </button>
                  ))}
                </div>
              </div>

              {/* Worker Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Assign Certified Field Worker
                </label>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {workers.map((worker) => {
                    const isSelected = selectedWorkerId === worker.id;
                    return (
                      <div
                        key={worker.id}
                        onClick={() => setSelectedWorkerId(worker.id)}
                        className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/70 shadow-xs ring-1 ring-indigo-500'
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${
                              isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {worker.name[0]}
                          </div>
                          <div>
                            <div className="text-xs font-black text-slate-900">{worker.name}</div>
                            <div className="text-[11px] text-slate-500">{worker.trade}</div>
                          </div>
                        </div>

                        <div className="text-right text-[11px] font-medium text-slate-600">
                          <div>★ {worker.rating}</div>
                          <div className="text-slate-400">{worker.activeTasks} active</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Instructions */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Panchayat Instructions to Worker
                </label>
                <textarea
                  rows={2}
                  value={workOrderNotes}
                  onChange={(e) => setWorkOrderNotes(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>

              {/* Actions */}
              <div className="pt-3 flex items-center justify-end space-x-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAssignModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAssign}
                  className="flex items-center space-x-1.5 bg-gradient-to-r from-amber-600 to-indigo-600 hover:from-amber-700 hover:to-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Dispatch Digital Work Order</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
